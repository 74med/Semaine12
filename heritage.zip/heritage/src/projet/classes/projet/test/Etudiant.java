/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.classes.projet.test;

import projet.classes.Personne;

/**
 *
 * @author mehdi
 */

    public class Etudiant extends Personne {
 
	private final String cne;
 
	public Etudiant(String nom, String prenom, String cne) {
		super(nom, prenom);
		this.cne = cne;
	}
 
	@Override
	public String toString() {
		return super.toString() + " mon CNE est: " + this.cne;
	}
 
}

    
    

