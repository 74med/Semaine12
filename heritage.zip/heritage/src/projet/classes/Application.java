/*
Travail à faire
1. Développer les classes dans le package "projet.classes".
o Chaque classe doit contenir un constructeur d'initialisation.
o Chaque classe doit redéfinir la méthode toString().
2. Développer une classe de Application dans le package "projet.test", dans cette classe on
demande de créer :
o deux étudiants.
o deux employés.
o deux professeurs.
o afficher les informations de chaque personne.
 */

package projet.classes;

import projet.classes.projet.test.Employe;
import projet.classes.projet.test.Etudiant;
import projet.classes.projet.test.Professeur;

/**
 *
 * @author mehdi
 */

 
public class Application {
	public static void main(String[] main) {
            
//La liste des employés :
//Je suis SAN MARTINO Kevin mon salaire est : 5000.0 EUROS
//Je suis COUGRAND THIBAULT mon salaire est: 5000.0 EUROS
            
		Employe[] employes = new Employe[2];
		employes[0] = new Employe("SAN MARTINO", "Kevin", 5000.0);
		employes[1] = new Employe("COUGRAND", "THIBAULT", 5000.0);
		System.out.println("La liste des employes : ");
		for (Employe e : employes)
			System.out.println("\t" + e);
 
// La liste des étudiants :
//Je suis DRUELLE Mehdi mon CNE est: 65678754
//Je suis TSOUKALAS IOANNA mon CNE est: 87543543
                
		Etudiant[] etudiants = new Etudiant[2];
		etudiants[0] = new Etudiant("DRUELLE", "Mehdi", "65678754");
		etudiants[1] = new Etudiant("TSOUKALAS", "IOANNA", "87543543");
		System.out.println("La liste des étudiants : ");
		for (Etudiant e : etudiants)
			System.out.println("\t" + e);
 
//La liste des professeurs :
//Je suis POURCELOT Sabrina mon salaire est : 2000.0 EUROS ma spécialité est: JAVA/JEE
//Je suis BRUSSET Pablo mon salaire est mon salaire est: 1800.0 EUROS ma spécialité est:
//Mathématique
                
		Professeur[] professeurs = new Professeur[2];
		professeurs[0] = new Professeur("POURCELOT", "Sabrina", 2000.0, "JAVA/JEE");
		professeurs[1] = new Professeur("BRUSSET", "Pablo", 1800.0, "Mathématique");
		System.out.println("La liste des professeurs : ");
		for (Professeur p : professeurs)
			System.out.println("\t" + p);
	}
}


