/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voiture;

/**
 *
 * @author mehdi
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Moto zzr = new Moto();
        System.out.println(zzr);

        zzr.setNbRoues(2);
        zzr.setMarque("Kawazaki");
        zzr.setPleinEssence(true);

        System.out.println(zzr);
        

        Moto cb500 = new Moto(2, " Honda ", true); //Nouvelle moto + Nom moto est egal a ma nouvelle moto avec comme parametre 2 roue, marque honda avec le plein.
        
        System.out.println(cb500);
        cb500.klaxon();
        
        
        
        Camion trafic = new Camion(4, "renault", true);
        System.out.println(trafic);
        trafic.klaxon();
        
        trafic.ilROUle();
        
    }

}
