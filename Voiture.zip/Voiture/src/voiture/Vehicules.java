/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voiture;

/**
 *
 * @author mehdi
 */
public class Vehicules {

    protected int nbRoues;
    protected String marque;
    protected boolean pleinEssence = false;
    boolean fin = false;

    public int getNbRoues() {
        return nbRoues;
    }

    public void setNbRoues(int nbRoues) {
        this.nbRoues = nbRoues;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public boolean isPleinEssence() {
        return pleinEssence;
    }

    public void setPleinEssence(boolean pleinEssence) {
        this.pleinEssence = pleinEssence;
    }

    @Override
    public String toString() {
        return "Vehicules{" + "nbRoues=" + nbRoues + ", marque=" + marque + ", pleinEssence=" + pleinEssence + '}';
    }

    public Vehicules(int nbRoues, String marque, boolean pleinEssence) {
        this.nbRoues = nbRoues;
        this.marque = marque;
        this.pleinEssence = pleinEssence;
    }

    public Vehicules() {

    }

    public void klaxon() {

        System.out.println("Bip BIp");
    }

    public boolean ilROUle() {

        if ((pleinEssence == false)) {
            System.out.println("tu n'a bientot plus d'eesence \n il faut vite faire le plein !!");
            System.out.println(this.toString());
            fin = true;
        }
        return fin;
    }

}
