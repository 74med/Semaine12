/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voiture;

/**
 *
 * @author mehdi
 */
public class Moto extends Vehicules{

//    private int nbRoues;
//    private String marque;
//    boolean pleinEssence = false;

    public Moto(int nbRoues, String marque, boolean pleinEssence) {
        super(nbRoues, marque, pleinEssence);
    }

    
    
    public Moto() {
       super();
        
    }

    @Override
    public String toString() {
        return "Moto{" + "nbRoues=" + nbRoues + ", marque=" + marque + ", pleinEssence=" + pleinEssence + '}';
    }

    
//    public int getNbRoues() {
//        return nbRoues;
//    }
//
//    public void setNbRoues(int nbRoues) {
//        this.nbRoues = nbRoues;
//    }
//
//    public String getMarque() {
//        return marque;
//    }
//
//    public void setMarque(String marque) {
//        this.marque = marque;
//    }
//
//    public boolean isPleinEssence() {
//        return pleinEssence;
//    }
//
//    public void setPleinEssence(boolean pleinEssence) {
//        this.pleinEssence = pleinEssence;
//}

//      PLus besoin des getter and setter, on les re creer dans la superclasse vehicules
    
}
