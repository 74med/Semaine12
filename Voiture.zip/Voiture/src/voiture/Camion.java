/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voiture;

/**
 *
 * @author mehdi
 */
public class Camion extends Vehicules {
    
//    private int nbRoues;
//    private String marque;
//    boolean pleinEssence = false;
      
      
      
    @Override
    public String toString() {
        return "Camion{" + super.toString() + '}';
    }

//
//    public int getNbRoues() {
//        return nbRoues;
//    }
//
//    public void setNbRoues(int nbRoues) {
//        this.nbRoues = nbRoues;
//    }
//
//    public String getMarque() {
//        return marque;
//    }
//
//    public void setMarque(String marque) {
//        this.marque = marque;
//    }
//
//    public boolean isPleinEssence() {
//        return pleinEssence;
//    }
//
//    public void setPleinEssence(boolean pleinEssence) {
//        this.pleinEssence = pleinEssence;
//    }
    public Camion(int nbRoues, String marque, boolean pleinEssence) {
        super(nbRoues, marque, pleinEssence);
    }
    
    public Camion() {
        super();
        
    }
    
    
 
    
}
