package Tamagotchi;

import java.util.Scanner;

/**
 * Ligne supérieure Informations Faim, moral, éducation, âge, poids, prénom,
 * sexe, génération Repas Plat ou friandise, Toilette Jeux Danse ou saut
 * d'obstacles
 *
 * @author mehdi
 *
 */
public class Tama {

    private char sexe = 'H';
    // private String couleur = "";
    private String nom;

    private int Fain = 10, Moral = 10, Education = 10, Maladie = 0, Poids = 10, Hygiene = 10, Sante = 10;
    boolean fin = false;

    /**
     * @param pNom
     * @param pSexe
     */
//    public Tama(char pSexe, String pNom) {
//        
//         setSexe(pSexe);
//        nom = pNom;
//        //couleur = pCouleur;
//        System.out.println("\n Votre Tamagotchi du nom de " + nom + " dois maintenant choisir une couleur \n ");
//    }
    public Tama(char pSexe, String pNom) {

        setSexe(pSexe);
        nom = pNom;
        //couleur = pCouleur;
        System.out.println("\n Votre Tamagotchi du nom de " + nom + " dois maintenant choisir une couleur \n ");
    }

    Tama() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return "Tamagotchi" + "\n" + " ||" + "Fain=" + Fain + "||" + ",||" + "Moral=" + Moral
                + "||" + ", ||" + "Education=" + Education + "||" + ", ||" + "Maladie=" + Maladie + "||" + ", ||" + "Poids=" + Poids + "||" + ", ||" + "Hygiene=" + Hygiene
                + "||" + ", ||" + "Sante=" + Sante + "||" + "";
        //sexe=" + sexe + ", nom=" + nom + ", 
    }

    //----------------------------getter & setter-------------------------------//
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public char getSexe() {
        return sexe;
    }

    public final void setSexe(char sexe) {
        this.sexe = sexe;
    }

    public int getFain() {
        return Fain;
    }

    public void setFain(int Fain) {
        if (Fain > 20) {
            this.Fain = 20;
        } else if (Fain < 0) {
            this.Fain = 0;
        } else {
            this.Fain = Fain;
        }
    }

    public void addFain(int ajout) {
        int newFain = this.Fain + ajout;
        this.setFain(newFain);
    }

    public int getMoral() {
        return Moral;
    }

    public void setMoral(int Moral) {
        if (Moral > 20) {
            this.Moral = 20;
        } else if (Moral < 0) {
            this.Moral = 0;
        } else {
            this.Moral = Moral;
        }

    }

    public void addMoral(int ajout) {
        int newMoral = this.Moral + ajout;
        this.setMoral(newMoral);
    }

    public int getEducation() {
        return Education;
    }

    public void setEducation(int Education) {

        if (Education > 20) {
            this.Education = 20;
        } else if (Education < 0) {
            this.Education = 0;
        } else {
            this.Education = Education;
        }

    }

    public void addEducation(int ajout) {
        int newReflexe = this.Education + ajout;
        this.setEducation(newReflexe);
    }

    public int getMaladie() {
        return Maladie;
    }

    public void setMaladie(int Maladie) {
        if (Maladie > 20) {
            this.Maladie = 20;
        } else if (Maladie < 0) {
            this.Maladie = 0;
        } else {
            this.Maladie = Maladie;
        }

    }

    public void addMaladie(int ajout) {
        int newMaladie = this.Maladie + ajout;
        this.setMaladie(newMaladie);
    }

    public int getPoids() {
        return Poids;
    }

    public void setPoids(int Poids) {

        if (Poids > 20) {
            this.Poids = 20;
        } else if (Poids < 0) {
            this.Poids = 0;
        } else {
            this.Poids = Poids;
        }

    }

    public void addPoids(int ajout) {
        int newPoids = this.Poids + ajout;
        this.setPoids(newPoids);
    }

    public int getHygiene() {
        return Hygiene;
    }

    public void setHygiene(int Hygiene) {

        if (Hygiene > 20) {
            this.Hygiene = 20;
        } else if (Hygiene < 0) {
            this.Hygiene = 0;
        } else {
            this.Hygiene = Hygiene;
        }

    }

    public void addHygiene(int ajout) {
        int newHygiene = this.Hygiene + ajout;
        this.setHygiene(newHygiene);
    }

    public int getSante() {
        return Sante;
    }

    public void setSante(int Sante) {
        if (Sante > 20) {
            this.Sante = 20;
        } else if (Sante < 0) {
            this.Sante = 0;
        } else {
            this.Sante = Sante;
        }

    }

    public void addSante(int ajout) {
        int newSante = this.Sante + ajout;
        this.setSante(newSante);

    }

    //-------------------------Fin getter & setter-------------------------------//
    //-----------------------------Scenario-------------------------------//
    public void goMangerLivraison() {
        String outPutDial;
        //outPutDial = "\n " + nom + " vous avez choisis la livraison a domicile ! votre tamagotchi est sur le point de commander un kebab! \n ";
        this.addFain(2);
        this.addMoral(4);
        this.addEducation(-1);
        this.addMaladie(0);
        this.addPoids(4);
        this.addHygiene(-1);
        this.addSante(1);
    }

    public void goMangerVille() {
        System.out.println("\n " + nom + "\n vous avez choisis de partir manger en ville ! votre tamagotchi  est sur le point de partir manger un subway ! \n ");
        this.addFain(4);
        this.addMoral(2);
        this.addEducation(1);
        this.addMaladie(0);
        this.addPoids(2);
        this.addHygiene(-1);
        this.addSante(1);
    }

    public void goNoManger() {
        System.out.println("\n " + nom + "\n vous avez choisis de ne pas manger ! votre tamagotchi est sur le point de faire une greve de la fin ! \n ");
        this.addFain(-2);
        this.addMoral(-2);
        this.addEducation(0);
        this.addMaladie(2);
        this.addPoids(0);
        this.addHygiene(-1);
        this.addSante(-1);
    }

    public void senarManger() {

        Scanner sc = new Scanner(System.in);
        boolean choixManger = true;
        while (choixManger) {
            if (choixManger == true) {
                //System.out.println("\n 1 = livraison a domicile || 2 = Partir manger en ville || 3 = On mange pas !!! nous sommes des fous \n ");
                int manger = sc.nextInt();
                sc.nextLine();
                switch (manger) {
                    case 1:
                        goMangerLivraison();
                        choixManger = false;
                        break;
                    case 2:
                        goMangerVille();
                        choixManger = false;
                        break;
                    case 3:
                        goNoManger();
                        choixManger = false;
                        break;

                    default:
                        System.out.println("\n Erreur critique !! Veuillez choisir parmis les trois choix proposé ! \n");
                        choixManger = true;
                        break;
                }
            }
        }
    }

    public void goActiviteRando() {
        System.out.println(nom + "\n vous avez choisis la randonnée ! votre tamagotchi est pret pour un trek d'exception ! \n ");
        this.addFain(-4);
        this.addMoral(3);
        this.addEducation(0);
        this.addMaladie(0);
        this.addPoids(-2);
        this.addHygiene(-3);
        this.addSante(1);
    }

    public void goActivitePara() {
        System.out.println(nom + "\n vous avez choisis les sensations forte ! votre tamagotchi sans souviendra toute ca vie... si il survie !! \n ");
        this.addFain(-2);
        this.addMoral(4);
        this.addEducation(0);
        this.addMaladie(0);
        this.addPoids(-1);
        this.addHygiene(-2);
        this.addSante(1);
    }

    public void goActiviteJeux() {
        System.out.println(nom + "\n vous avez choisis les jeux video ! votre tamagotchi adore vraiment beaucoup passé son temps a joué mais... ! \n ");
        this.addFain(-5);
        this.addMoral(2);
        this.addEducation(-1);
        this.addMaladie(0);
        this.addPoids(-1);
        this.addHygiene(-3);
        this.addSante(1);
    }

    public void senarActivite() {
        Scanner sc = new Scanner(System.in);
        boolean choixActivite = true;
        while (choixActivite) {
            if (choixActivite == true) {
                System.out.println("\n 1 = Randonnée || 2 = Parachute || 3 = Jeux video \n ");
                int activite = sc.nextInt();
                sc.nextLine();
                switch (activite) {
                    case 1:
                        goActiviteRando();
                        choixActivite = false;
                        break;
                    case 2:
                        goActivitePara();
                        choixActivite = false;
                        break;
                    case 3:
                        goActiviteJeux();
                        choixActivite = false;
                        break;
                    default:
                        System.out.println("\n Erreur critique !! Veuillez choisir parmis les trois choix proposé ! \n");
                        choixActivite = true;
                        break;
                }
            }
        }
    }

    public void goEducationJava() {

        System.out.println(nom + "\n C'est partie pour un cours sur Java ! \n pour des raisons de securite, veuillez accrochez votre cerveau correctement \n");
        this.addFain(-3);
        this.addMoral(-1);
        this.addEducation(5);
        this.addMaladie(2);
        this.addPoids(0);
        this.addHygiene(-1);
        this.addSante(0);

    }

    public void goEducationHTML() {

        System.out.println(nom + "\n HTML/CSS ! rien ne vous effraye ...  !! \n ");
        this.addFain(-2);
        this.addMoral(0);
        this.addEducation(3);
        this.addMaladie(2);
        this.addPoids(0);
        this.addHygiene(-1);
        this.addSante(0);

    }

    public void goEducationGeneral() {

        System.out.println("\n Un peu de langues de math de sciences !! cela fait toujours un bien fou ! \n ");
        this.addFain(-2);
        this.addMoral(0);
        this.addEducation(4);
        this.addMaladie(2);
        this.addPoids(0);
        this.addHygiene(-2);
        this.addSante(1);

    }

    public void goNoEducation() {

        System.out.println("\n Toujours pareil !! quand tu regarde ta montre, \n tu te dit ! c'est deja l'heure de l'apreo et bas go !! \n ");
        this.addFain(-3);
        this.addMoral(3);
        this.addEducation(0);
        this.addMaladie(1);
        this.addPoids(2);
        this.addHygiene(-2);
        this.addSante(1);

    }

    public void senarEducation() {

        Scanner sc = new Scanner(System.in);
        boolean choixEducation = true;
        while (choixEducation) {
            if (choixEducation == true) {
                System.out.println("\n 1 = Java || 2 = HTML/CSS || 3 = Culture general || 4 = Apéro party \n ");
                int education = sc.nextInt();
                sc.nextLine();
                switch (education) {
                    case 1:
                        goEducationJava();
                        choixEducation = false;
                        break;
                    case 2:
                        goEducationHTML();
                        choixEducation = false;
                        break;
                    case 3:
                        goEducationGeneral();
                        choixEducation = false;
                        break;
                    case 4:
                        goNoEducation();
                        choixEducation = false;
                        break;
                    default:
                        System.out.println("\n Erreur critique !! Veuillez choisir parmis les trois choix proposé ! \n");
                        choixEducation = true;
                        break;
                }
            }
        }
    }

    public void goHygieneDouche() {
        System.out.println(nom + "\n Aller hop à la douche ! votre tamagotchi saute dans la douche.. ! \n ");
        this.addFain(-2);
        this.addMoral(1);
        this.addEducation(0);
        this.addMaladie(-1);
        this.addPoids(0);
        this.addHygiene(2);
        this.addSante(1);
    }

    public void goHygieneBain() {
        System.out.println(nom + "\n Rien ne vaut un bon bain bien chaud ! votre tamagotchi se relax dans l'eau chaude !! \n ");
        this.addFain(-3);
        this.addMoral(2);
        this.addEducation(0);
        this.addMaladie(-1);
        this.addPoids(0);
        this.addHygiene(4);
        this.addSante(1);
    }

    public void goNoHygiene() {
        System.out.println(nom + "\n Pas le temps pour se laver c'est deja l'heure de l'apero ! votre tamagotchi est toujours partant pour un happy hour... ! \n ");
        this.addFain(0);
        this.addMoral(-2);
        this.addEducation(0);
        this.addMaladie(1);
        this.addPoids(0);
        this.addHygiene(-4);
        this.addSante(-3);
    }

    public void senarHygiene() {
        Scanner sc = new Scanner(System.in);
        boolean choixHygiene = true;
        while (choixHygiene) {
            if (choixHygiene == true) {
                System.out.println("\n 1 = Douche || 2 = Bain || 3 = Finalement on s'en fou... \n ");
                int hygiene = sc.nextInt();
                sc.nextLine();
                switch (hygiene) {
                    case 1:
                        goHygieneDouche();
                        choixHygiene = false;
                        break;
                    case 2:
                        goHygieneBain();
                        choixHygiene = false;
                        break;
                    case 3:
                        goNoHygiene();
                        choixHygiene = false;
                        break;
                    default:
                        System.out.println("\n Erreur critique !! auto-destrucion dans 3 essais ! \n");
                        choixHygiene = true;
                        break;
                }
            }
        }
    }

    public void goFumerCig() {
        this.addFain(-4);
        this.addMoral(1);
        this.addEducation(-2);
        this.addMaladie(5);
        this.addPoids(0);
        this.addHygiene(-2);
        this.addSante(-3);
        //return nom + "\n Café, clope, le reveil du cyclope !! \n";
    }

    public void goFumerPipe() {
        System.out.println(nom + "\n Comme papy, alors que j'ai quinze ans mais ca a du style... \n ");
        this.addFain(-5);
        this.addMoral(1);
        this.addEducation(-2);
        this.addMaladie(3);
        this.addPoids(0);
        this.addHygiene(-2);
        this.addSante(-1);
    }

    public void goFumerJoint() {

        System.out.println(nom + "\n FFFffff....rrhhaaa...FFfffff......rrrhhhaaaa.... \n C'2 LA BONNE \n ");
        this.addFain(-6);
        this.addMoral(4);
        this.addEducation(-2);
        this.addMaladie(1);
        this.addPoids(0);
        this.addHygiene(-2);
        this.addSante(-2);
    }

    public void goNoFumer() {
        System.out.println(nom + "\n La fumette c'est pour les tapettes !! c'est bon j'arrete... jusqu'a la prochaine ! \n ");
        this.addFain(0);
        this.addMoral(0);
        this.addEducation(1);
        this.addMaladie(-2);
        this.addPoids(0);
        this.addHygiene(0);
        this.addSante(3);
    }

    public void senarFumer() {
        Scanner sc = new Scanner(System.in);
        boolean choixFumer = true;
        while (choixFumer) {
            if (choixFumer == true) {
                System.out.println("\n 1 = Cigarette || 2 = Pipe a l'ancienne || 3 = Joint || 4 = Fini pour moi \n ");
                int fumer = sc.nextInt();
                sc.nextLine();
                switch (fumer) {
                    case 1:
                        goFumerCig();
                        choixFumer = false;
                        //System.out.println("\n Café, clope, le reveil du cyclope !! \n");
                        break;
                    case 2:
                        goFumerPipe();
                        choixFumer = false;
                        break;
                    case 3:
                        goFumerJoint();
                        choixFumer = false;
                        break;
                    case 4:
                        goNoFumer();
                        choixFumer = false;
                        break;
                    default:
                        System.out.println("\n Erreur critique !! Veuillez choisir parmis les 4 choix proposé ! \n");
                        choixFumer = true;
                        break;
                }
            }
        }
    }

    public void goDormirHamac() {
        System.out.println(nom + "\n Tres bon choix, une nuit a la belle etoile !! \n ");
        this.addFain(-3);
        this.addMoral(4);
        this.addEducation(0);
        this.addMaladie(0);
        this.addPoids(0);
        this.addHygiene(0);
        this.addSante(2);
    }

    public void goDormirLit() {
        System.out.println(nom + "\n Mon lit, mon lit, rien ne vaut mon lit... !! \n Quoi que \n ");
        this.addFain(-2);
        this.addMoral(2);
        this.addEducation(0);
        this.addMaladie(0);
        this.addPoids(0);
        this.addHygiene(0);
        this.addSante(4);
    }

    public void goNoDormir() {
        System.out.println(nom + "\n Apero !! after !! Danse !! Musique !! A ba il fait deja jour !! \n ");
        this.addFain(-3);
        this.addMoral(-1);
        this.addEducation(0);
        this.addMaladie(3);
        this.addPoids(0);
        this.addHygiene(-2);
        this.addSante(-2);
    }

    public void senarDormir() {
        Scanner sc = new Scanner(System.in);
        boolean choixDormir = true;
        while (choixDormir) {
            if (choixDormir == true) {
                System.out.println("\n 1 = Hamac || 2 = Lit || 3 = Nuit Blanche \n ");
                int dormir = sc.nextInt();
                sc.nextLine();
                switch (dormir) {
                    case 1:
                        goDormirHamac();
                        choixDormir = false;
                        break;
                    case 2:
                        goDormirLit();
                        choixDormir = false;
                        break;
                    case 3:
                        goNoDormir();
                        choixDormir = false;
                        break;
                    default:
                        System.out.println("\n Erreur critique !! Veuillez choisir parmis les trois choix proposé ! \n");
                        choixDormir = true;
                        break;
                }
            }
        }
    }

    public void goPendaison() {
        System.out.println(nom + "\n Votre tamagotchi attrape une chaise, une corde et fait un noeud, monte sur la chaise et CRACK.. \n GAME OVER ! \n ");
        setFain(0);
        setMoral(0);
        setEducation(0);
        setMaladie(20);
        setPoids(0);
        setHygiene(0);
        setSante(0);
    }

    public void goArme() {
        System.out.println(nom + "\n Votre tamagotchi se relax sur le canapé quand tout a coup, il saisie son arme posé sur la table juste devant lui, \n ce met le canon dans la bouche et PPWWWOOUUAAAHH \n GAME OVER \n ");
        setFain(0);
        setMoral(0);
        setEducation(0);
        setMaladie(20);
        setPoids(0);
        setHygiene(0);
        setSante(0);
    }

    public void goNoSuicide() {
        System.out.println(nom + "\n C'est encorel'heure de l'apero !! tant qu'il y a Apero je serais la !! \n ");
        this.addFain(0);
        this.addMoral(0);
        this.addEducation(0);
        this.addMaladie(0);
        this.addPoids(0);
        this.addHygiene(0);
        this.addSante(0);
    }

    public void senarSuicide() {
        Scanner sc = new Scanner(System.in);
        System.out.println(nom + " Vous etes chez vous, vous avez le choix entre 3 options pour mettre fin a la partie !! la quel choisira tu  ?  \n  ");

        boolean choixSuicide = true;
        while (choixSuicide) {
            if (choixSuicide == true) {
                System.out.println("\n 1 = Pendaison || 2 = Arme a feu || 3 = Hey je crois que je vais encore y reflechir un peu... \n ");
                int suicide = sc.nextInt();
                sc.nextLine();
                switch (suicide) {
                    case 1:
                        goPendaison();
                        //System.out.println("\n Votre tamagotchi attrape une chaise, une corde et fait un noeud, monte sur la chaise et CRACK.. \n GAME OVER ! \n ");
                        choixSuicide = false;
                        break;
                    case 2:
                        goArme();
                        //System.out.println("\n Votre tamagotchi se relax sur le canapé quand tout a coup, il saisie son arme posé sur la table juste devant lui, \n ce met le canon dans la bouche et PPWWWOOUUAAAHH \n GAME OVER \n ");
                        choixSuicide = false;
                        break;
                    case 3:
                        goNoSuicide();
                        //System.out.println("\n C'est encorel'heure de l'apero !! tant qu'il y a Apero je serais la !! \n ");
                        choixSuicide = true;
                        break;
                    default:
                        System.out.println("\n Erreur critique !! Erreur critique !! Veuillez choisir comment mettre fin à vos jours ! \n");
                        break;
                }
            }
            this.fin = true;
            sc.close();
        }

    }

    //-----------------------------Fin scenario-------------------------------//
    //--------------------------Choix activite-----------------------------//
    public void choixActivite() {

        System.out.println("\n  " + nom + "  l'heure tourne, que veux tu faire ? \n " + " \n " + " 1-Manger " + " \n " + " 2-Sport " + " \n " + " 3-Apprendre " + " \n " + " 4-Se laver " + " \n " + " 5-Dormir " + " \n " + " 6-Fumer " + " \n " + " 7-Suicide \n");
        String activite = TamaMain.sc.nextLine();
        switch (activite) {

            case "1":
                senarManger();
                break;
            case "2":
                senarActivite();
                break;
            case "3":
                senarEducation();
                break;
            case "4":
                senarHygiene();
                break;
            case "5":
                senarDormir();
                break;
            case "6":
                senarFumer();
                break;
            case "7":
                senarSuicide();
                break;
        }
    }
    //--------------------------Fin choix activite-----------------------------//

    public void actualiseStatu() {

        VueTama.jTextFieldSanteVal.setText(getSante() + "");
        VueTama.jTextFieldFainVal.setText(getFain() + "");
        VueTama.jTextFieldMoralVal.setText(getMoral() + "");
        VueTama.jTextFieldEducationVal.setText(getEducation() + "");
        VueTama.jTextFieldMaladieVal.setText(getMaladie() + "");
        VueTama.jTextFieldPoidsVal.setText(getPoids() + "");
        VueTama.jTextFieldHygieneVal.setText(getHygiene() + "");

    }

    //--------------------------------Alerts----------------------------------//
    public void alert() {

        if (Sante >= 15) {
            System.out.println("Super " + nom + " vous etes en bonne santé ");
        } else if (Fain >= 15) {
            System.out.println("Cool " + nom + " Ton ventre est plein !! ");
        }
        if (Moral >= 15) {
            System.out.println("Whaou " + nom + " tu te sens super bien moralement !! ");
        } else if (Poids >= 16) {
            System.out.println("attention votre tamagotchi est assez gros pensez a faire des activitées !! ");
        }
        if (Hygiene >= 16) {
            System.out.println("Humm " + nom + " Axe plus tant met plus tant a !! ");
        }
    }

    public void alertDanger() {
        if (Sante <= 6) {
            System.out.println("attention " + nom + " pensez a verifier votre santé ! ");
        } else if (Poids <= 6 || Poids >= 18) {
            System.out.println("attention votre tamagotchi a des problemes de poids");
        }
        if (Moral <= 6) {
            System.out.println("attention " + nom + " atteind un niveau de moral Extremement nocif ");
        } else if (Fain <= 6) {
            System.out.println("attention " + nom + " est faible, il atteind un niveau critique, besoin de manger !! ");
        }
        if (Maladie >= 16) {
            System.out.println("attention " + nom + " peut être un debut de grippe en prevision!! ");
        } else if (Hygiene <= 6) {
            System.out.println("attention vous commencez à etre plutot sale !! ");
        }
    }
    //--------------------------------Alerts Fin-----------------------------//

    //-------------------------------Finish---------------------------------//
    public boolean finish() {

        if ((Sante == 0 || Poids == 0 || Moral == 0 || Fain == 0 || Maladie == 20 || Hygiene == 0)) {
            System.out.println("ton tamagotchi est mort !! qu'a tu fait ? \n ésperont que tu n'est jamais d'enfant !!");
            System.out.println(this.toString());
            fin = true;
        }
        return fin;
    }
    //-------------------------------Finish Fin---------------------------------//
}
