//Ligne supérieure
//Informations
//Faim, moral, éducation, âge, poids, prénom, sexe, génération
//Repas
//Plat ou friandise,
//Toilette
//Jeux
//Danse ou saut d'obstacles
package Tamagotchi;

import java.util.Scanner;

public class TamaMain {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		//-----------------------------------------Choix du sexe-----------------------------------------//
		boolean flag = true;
		int c = 0;
		char sexe = '?';
		String saisieU;
		while (flag) {
			System.out.println("  Veuillez choisir le sexe || --> M <-- || --> F <-- || \n ");
			saisieU = sc.nextLine();	
			if (saisieU.equalsIgnoreCase("M") || saisieU.equalsIgnoreCase("F")) {

				sexe = saisieU.charAt(0);
				flag = false;
			} else {
				System.out.println("  Attention sexe inconnu \n");
			}
			c++;
			if (c > 3) {
				flag = false;
			}
		}
		//-----------------------------------------Fin choix du nom-----------------------------------------//



		


		//-----------------------------------------Choix du nom-----------------------------------------//
		System.out.println("\n Veuillez choisir un nom pour votre Tamagotchi \n ");
		saisieU = sc.nextLine();
		Tama monTama = new Tama(sexe, saisieU);
		//-----------------------------------------Fin choix du nom-----------------------------------------//







		//-----------------------------------------Choix de la couleur-----------------------------------------//
		boolean choixCouleur = true;
		while (choixCouleur) {
			System.out.println(" 1 = Blanc || 2 = Rouge || 3 = Bleu \n ");
			int sponsor = sc.nextInt();
			sc.nextLine(); 
			switch (sponsor) {
			case 1:
				System.out.println("\n vous avez choisis Blanc comme couleur principale ! votre tamagotchi " + saisieU + " est sur le point de naître ! \n ");
				choixCouleur = false;
				break;
			case 2:
				System.out.println("\n vous avez choisis Rouge comme couleur principale ! votre tamagotchi " + saisieU + " est sur le point de naître ! \n ");
				choixCouleur = false;
				break;
			case 3:
				System.out.println("\n vous avez choisis Bleu comme couleur principale ! votre tamagotchi " + saisieU + " est sur le point de naître ! \n ");
				choixCouleur = false;
				break;
			default:
				System.out.println("Erreur critique !! Veuillez choisir une couleure valide parmis les trois choix proposé");
				break;
			}
		}
		//-----------------------------------------Fin choix de la couleur--------------------------------------//






		//-----------------------------------------choix de l'activite-----------------------------------------//

		while (monTama.finish() == false) {

			System.out.println("\b Voici les stats de ton " + monTama +"\n");
			monTama.alert();
			monTama.alertDanger();
			monTama.choixActivite();

		}
		sc.close();
	}
}
