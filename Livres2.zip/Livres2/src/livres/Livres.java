/*
Livres
1. Définir une classe Livre avec les attributs suivants : Id, Titre, Auteur (Nom complet), Prix.
2. Définir les accesseurs aux différents attributs de la classe.
3. Définir un constructeur permettant d’initialiser les attributs d'un objet livre par des valeurs
saisies par l’utilisateur. Sachant que Id doit être auto-incrément.
4. Définir la méthode toString ( ) permettant d’afficher les informations du livre en cours.
5. Écrire un programme testant la classe Livre.
 */
package livres;

/**
 *
 * @author mehdi
 */

public class Livres {
	private int id;
	private String titre;
	private String auteur;
	private int prix;
	public static int count;
 
	public Livres(String titre, String auteur, int prix) {
		this.id = ++count;
		this.titre = titre;
		this.auteur = auteur;
		this.prix = prix;
	}
 
	public int getId() {
		return id;
	}
 
	public void setId(int id) {
		this.id = id;
	}
 
	public String getTitre() {
		return titre;
	}
 
	public void setTitre(String titre) {
		this.titre = titre;
	}
 
	public String getAuteur() {
		return auteur;
	}
 
	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}
 
	public int getPrix() {
		return prix;
	}
 
	public void setPrix(int prix) {
		this.prix = prix;
	}
 
	@Override
	public String toString() {
		return "Le prix du livre " + this.titre + " de l'auteur " + this.auteur
				+ " est :" + this.prix + " DH";
	}
 
}



//public class Livres {
//
//    int id;         // int par defaut = 0
//    String titre;   // String par defaut = null 
//    String auteur;
//    int prix;
//
//    @Override
//    public String toString() {
//        return "Livres{" + "id=" + id + ", titre=" + titre + ", auteur=" + auteur + ", prix=" + prix + '}';
//    }
//
//    public int getId() {
//        return id;
//    }
//
//    public void setId(int id) {
//        this.id = id;
//
////         if (id >= 0) {
////        } else if (id < 0) {
////            this.id = 0;
////        } else {
////            this.id = id;
//   }
//
//    public void addId(int ajout) {
//        int newId = this.id + ajout;
//        this.setId(newId);
//    }
//
//    public String getTitre() {
//        return titre;
//    }
//
//    public void setTitre(String titre) {
//        this.titre = titre;
//    }
//
//    public String getAuteur() {
//        return auteur;
//    }
//
//    public void setAuteur(String auteur) {
//        this.auteur = auteur;
//    }
//
//    public int getPrix() {
//        return prix;
//    }
//
//    public void setPrix(int prix) {
//        this.prix = prix;
//    }
//
//    public Livres(int id, String titre, String auteur, int prix) {
//        this.id = id;
//        this.titre = titre;
//        this.auteur = auteur;
//        this.prix = prix;
//    }
//
//    public Livres() {
//
//    }
//
//    /**
//     *
//     */
//    
//    
//   
//    
//}
