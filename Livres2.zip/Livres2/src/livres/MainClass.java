/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package livres;

import java.util.Scanner;

/**
 *
 * @author mehdi
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    
    
    
    public static void main(String[] args) {
		Livres[] livres = new Livres[3];
		Scanner sc = null;
		for (int i = 0; i < livres.length; i++) {
			sc = new Scanner(System.in);
			System.out.print("Donner le titre du livre n°  " + (i + 1) + " :");
			String titre = sc.nextLine();
			System.out.print("Donner l'auteur du livre n°  " + (i + 1) + " :");
			String auteur = sc.nextLine();
			System.out.print("Donner le prix du livre n°  " + (i + 1) + " :");
			int prix = sc.nextInt();
			livres[i] = new Livres(titre, auteur, prix);
		}
		sc.close();
		for (Livres l : livres)
			System.out.println(l);
 
		System.out.println("Le nombre de livres est " + Livres.count);
	}
 
//Source : www.exelib.net
            
        
    
          
        
        
// System.out.println("id" + id);

//        Livres anglais = new Livres();
//        
//        System.out.println(anglais);          



//System.out.println("Le prix du livre " + prix + " de l'auteur " + auteur + " est " + prix + " EUROS");  
        
        
        
//Donner le titre du livre n° 1 ? Javascript en 10 leçons
//Donner l'auteur du livre n° 1 ? JAHAN ERIC
//Donner le prix du livre n° 1 ? 20
//Donner le titre du livre n° 2 ? JAVA 
    }
//public void saisiU(){
//        
//        Livres horreur = new Livres();
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Veuillez choisir un titre");
//        horreur.setTitre(sc.nextLine());
//        System.out.println("Veuillez choisir un auteur");
//        horreur.setAuteur(sc.nextLine());
//        System.out.println("Prix");
//        horreur.setPrix(sc.nextInt());
//
//}